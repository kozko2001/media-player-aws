console.log("hello world!")

function handler() {
  console.log("I'm the handler")
}

module.exports = {
  handler: handler
}
